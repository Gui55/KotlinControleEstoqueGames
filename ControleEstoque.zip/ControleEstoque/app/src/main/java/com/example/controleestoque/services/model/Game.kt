package com.example.controleestoque.services.model

data class Game(val id: Int,
                val name: String,
                val image: String,
                val company: String,
                val stock: Int)